package main;

public class Player {

	int x = 100;
	int y = 100;
	int speed = 3;
	int health = 100;
	
}
