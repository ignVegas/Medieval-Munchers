package World;

import java.awt.image.BufferedImage;

public class Tile {

	public BufferedImage im;
	public boolean coll = false;
}
